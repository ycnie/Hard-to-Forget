#### package to install

##### react bootstrap
$ npm install --save react react-dom
$ npm install --save react-bootstrap

<!-- #### progress bar
$ npm install --save react-progressbar.js
https://github.com/kimmobrunfeldt/react-progressbar.js/ -->

<!-- ##### updater
$ npm install immutability-helper -->

##### Router
$ npm install --save react-router